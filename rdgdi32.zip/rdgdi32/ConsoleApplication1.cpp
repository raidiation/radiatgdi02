#include <iostream>
#include <Windows.h>
#define MYRGB(r,g,b) (r | g << 15 | b << 26)
using namespace std;
int main()
{


	LPCWSTR lptext = L"Radiantgdi02";
	while (true) {

		HDC hdc;
		hdc = GetWindowDC(GetDesktopWindow());
		int sw = GetSystemMetrics(0);
		int sh = GetSystemMetrics(1);
		SetTextColor(hdc, MYRGB(255, 255, 0));
		SetBkColor(hdc, MYRGB(255, 182, 193));
		TextOutW(hdc, rand() % sw, rand() % sh, lptext, wcslen(lptext));
		TextOutW(hdc, rand() % sw, rand() % sh, lptext, wcslen(lptext));
		TextOutW(hdc, rand() % sw, rand() % sh, lptext, wcslen(lptext));
	}
}

